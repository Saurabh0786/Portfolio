# HTML-CSS-Mini-Project-portfolio


This is a mini project and specially for the beginners. We will show you how you can turn the website into a  responsive design. We will see how to create responsive navigation bar with Mobile hamburger menu and how to make flip box box with css. There are many thing that you can learn through the practice.
